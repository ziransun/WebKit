browser.test.notifyPass('Popup loaded successfully');
